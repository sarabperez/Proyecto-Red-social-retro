import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import UserLogin from './components/Login/Login.component';
import UserRegister from './components/Register/Register.component';
import MainPage from './components/MainPage/MainPage.component';
import AddForm from './components/AddForm/AddForm.component';
import ProfilePage from './components/Profile/Profile.component';
import DetailCard from './components/DetailState/Details.component';
import EditProfile from './components/Profile/EditProfile.component';

function App() {
  return (

    <Router>
      <Routes>
        <Route path="/Login" element={<UserLogin />} />
        <Route path="/Register" element={<UserRegister />} />
        <Route path='/states' element={<MainPage />} />
        <Route path='/states/new' element={<AddForm />} />
        <Route path='/profile' element={<ProfilePage />} />
        <Route path='/profile/edit' element={<EditProfile />} />
        <Route path='/states/:id' element={<DetailCard />} />
      </Routes>
    </Router>
  );
}

export default App;