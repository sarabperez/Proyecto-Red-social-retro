import React from 'react';
import 'nes.css/css/nes.min.css';
import '../MainPage/MainPage.style.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const StateCardWithDetele = (props) => {
    const navigate = useNavigate();
    const { id, title, image, user, description } = props;
    const truncateText = (text, maxLength) => {
        if (text.length > maxLength) {
            return text.substring(0, maxLength) + '...';
        } else {
            return text;
        }
    };

    const redirect = (id) => {
        navigate(`/states/${id}`);
    };

    const handleDeleteState = async () => {
        try {
            const response = await axios.delete(`http://localhost:5000/states/delete/${id}`);
            console.log(response);
        } catch (error) {
            console.error('Error deleting state:', error);
        }
    };

    return (
        <div className='tweet'>
            <div onClick={() => redirect(id)}>
                <div>
                    <h3 className='user-text'> @{user}</h3>
                </div>
                <div className="nes-container is-dark with-title" id='card-state'>
                    <img src={image} alt={user} className="img-user" />
                    <div>
                        <h2 className="tweet-text">{title}</h2>
                        <p className='tweet-text'>{truncateText(description, 40)}</p>
                    </div>
                </div>
            </div>
            <button onClick={handleDeleteState}>Delete</button>
        </div>
    );
}

export default StateCardWithDetele;


