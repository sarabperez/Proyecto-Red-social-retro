import React, { useState, useEffect } from 'react';
import 'nes.css/css/nes.min.css';
import Navbar from '../Navbar/Navbar.component';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../AddForm/AddForm.style.css';
import DragAndDropUploader from '../AddForm/DragAndDrop.component';

function EditProfile() {
    const navigate = useNavigate();
    const token = localStorage.getItem('token');
    const tokenData = JSON.parse(atob(token.split('.')[1]));
    const username = tokenData.username
    const [formData, setFormData] = useState({
        _id: '',
        username: '',
        description: '',
        profile: ''
    });

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/Users/all`);
                const user = response.data.find(user => user.username === username);
                if (user) {
                    setFormData({
                        _id: user._id,
                        username: user.username,
                        description: user.description,
                        profile: user.profile
                    });
                }
            } catch (error) {
                console.error('Error al obtener los datos del usuario', error.message);
            }
        };

        fetchUserData();
    }, [username]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    }

    const handleFileChange = (e) => {
        console.log('File selected:', e.target.files[0]);
        setFormData({ ...formData, [e.target.name]: e.target.files[0] });
    }


    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(formData);
        try {
            const data = new FormData();
            data.append('username', formData.username);
            data.append('description', formData.description);
            data.append('profile', formData.profile, formData.profile.name);


            const response = await axios.put(`http://localhost:5000/Users/editUser/${formData._id}`, data, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });


            console.log(response.data)

            localStorage.setItem("username", formData.username);
            navigate(`/profile`);
        } catch (error) {
            console.error('Error al actualizar el perfil', error.message);
        }
    };

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    return (
        <div className='nes-container is-dark' id='contenedor-princ'>
            <div>
                <Navbar />
            </div>
            <div className='nes-container is-rounded is-dark'>
                <form onSubmit={handleSubmit} className='contenedor-add'>
                    <div className='arriba'>
                        <div className='tweet-item'>
                            <label htmlFor="textarea_field" style={{ marginLeft: 75 }}>Imagen de perfil</label>

                        </div>
                    </div>
                    <div className="tweet-item">
                        <label htmlFor="image">Imagen de Perfil</label>
                        <input
                            type="file"
                            id="image"
                            name='profile'
                            className="nes-input is-success"
                            placeholder='Cargue imagen de perfil'
                            onChange={handleFileChange}
                            required
                        />
                    </div>


                    <div className='tweet-item'>
                        <label htmlFor="description">Descripción</label>
                        <textarea
                            id="description"
                            name='description'
                            className="nes-textarea"
                            placeholder='Ingrese una descripción'
                            value={formData.description}
                            onChange={handleChange}
                            required
                        />
                    </div>



                    <button type="submit" className="nes-btn is-success">Guardar cambios</button>
                </form>
            </div >
        </div >
    );
}

export default EditProfile;
