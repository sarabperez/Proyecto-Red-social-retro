import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../Navbar/Navbar.component';
import '../Profile/profile.style.css'
import StateCardWithDetele from './CardWithDelete.component';
import { useNavigate } from 'react-router-dom';

const ProfilePage = () => {
    const [userData, setUserData] = useState('');
    const [states, setStates] = useState([]);
    const token = localStorage.getItem('token');
    const tokenData = JSON.parse(atob(token.split('.')[1]));
    const username = tokenData.username
    const navigate = useNavigate();

    const truncateText = (text, maxLength) => {
        if (text.length > maxLength) {
            return text.substring(0, maxLength) + '...';
        } else {
            return text;
        }
    };

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const response = await axios.get('http://localhost:5000/Users/all');
                const userFind = response.data.find(user => user.username === username);
                setUserData(userFind);
                console.log(userFind);

                const responseStates = await axios.get(`http://localhost:5000/states/all`);
                const statesMatchingUser = responseStates.data.filter(state => state.user === username);
                setStates(statesMatchingUser);
                console.log(statesMatchingUser);

            } catch (error) {
                console.error('Error al obtener los datos del usuario:', error);
            }
        };

        fetchUserData();
    }, [states]);

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    console.log(`http://localhost:5000/upload/${userData.profile}`);


    return (
        <div className='nes-container is-dark'>
            <Navbar />
            <div className="nes-container is-rounded is-dark" id='profile'>
                <div className='info-user'>

                    {userData ? (
                        <div className="profile-info">
                            {userData.profile ? (
                                <img src={`http://localhost:5000/upload/${userData.profile}`} alt="Avatar" className="avatar" />
                            ) : (
                                <p>No profile picture available</p>
                            )}
                            <div className="user-details">
                                <h2>User: {userData.username}</h2>
                                <p>Description: {userData.description}</p>
                                <p>Email: {truncateText(userData.email, 35)}</p>
                                <a href='/profile/edit'>Edit Profile</a>
                                <div></div>
                                <a href='/states/new'>Agregar estado</a>
                            </div>
                        </div>
                    ) : (
                        <p>Cargando datos del usuario...</p>
                    )}
                </div>
                <div className="tweets">
                    <h2>Estados publicados</h2>

                    {states.map((element, index) => (
                        <StateCardWithDetele
                            key={index}
                            id={element._id}
                            title={element.title}
                            image={`http://localhost:5000/upload/${element.image}`}
                            user={element.user}
                            description={element.description}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;
