import React from 'react';
import 'nes.css/css/nes.min.css';
import '../MainPage/MainPage.style.css';
import '../DetailState/Details.style.css'
import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../Navbar/Navbar.component';
import { useNavigate } from 'react-router-dom';

const DetailCard = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const token = localStorage.getItem('token');
    const [state, setState] = useState({});
    const [comment, setComment] = useState({
        texto: ''
    });
    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/states/all`);
                const stateFind = response.data.find(state => state._id === id);
                setState(stateFind);
                console.log(stateFind);
            } catch (error) {
                console.error('Error al obtener los datos del usuario:', error);
            }
        };
        fetchUserData();
    }, [id, state]);

    const handleSubmit = async () => {
        if (comment.texto !== '') {
            try {
                const response = await axios.post(`http://localhost:5000/states/${id}/comments`, {
                    comment: comment.texto
                }, {
                    headers: { 
                        "Authorization": `Bearer ${token}` 
                    }
                })
                console.log(response);
            } catch (error) {
                console.error('Error adding comment:', error);
            }
        } else {
            alert("Escribe el comentario antes de publicarlo");
        }
    };

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    return (
        <div className='nes-container is-dark'>
            <Navbar />
            <div className='nes-container is-rounded is-dark' id='princ-container'>
                <div className='inside-container'>
                    <div className='profile-card' >
                        <h3> @{state.user}</h3>
                    </div>

                    <div className="nes-container is-dark" id='card-state'>
                        <div className='tweet'>
                            <h4 className="title">{state.title}</h4>
                            {console.log(state.imageUrl)}
                            <img src={"http://localhost:5000" + state.imageUrl} alt={state.user} className="tweet-img" />
                            <p className='paragraft'>{state.description}</p>
                        </div>
                    </div>

                    <div className="nuevo-comentario-form" style={{ marginLeft: 100, marginTop: 20, marginBottom: 20 }}>
                        <button
                            className='nes-btn'
                            type="button"
                            onClick={() => {
                                // mostrar u ocultar 
                                const form = document.getElementById('comment-form');
                                if (form.style.display === 'none') {
                                    form.style.display = 'block';
                                } else {
                                    form.style.display = 'none'; // Ocultar 
                                }
                            }}
                        >
                            Agregar Nuevo Comentario
                        </button>
                        <form id="comment-form" style={{ display: 'none' }} onSubmit={handleSubmit}>
                            <div className="form-group" style={{ marginTop: 20 }}>
                                <label htmlFor="texto">Texto del Comentario:</label>
                                <textarea
                                    type="text"
                                    id="texto"
                                    className='nes-textarea'
                                    value={comment.texto}
                                    onChange={(e) => setComment({ ...comment, texto: e.target.value })}
                                    required
                                >
                                </textarea>
                            </div>
                            <button type="submit" className='nes-btn is-success' style={{ marginLeft: 25 }}>Enviar Comentario</button>
                        </form>
                    </div>

                    <div>
                        {state.comments && state.comments.map((comentario, index) => (
                            <div key={index} className="nes-container is-dark with-title" style={{ marginTop: 30 }}>
                                <div className='comentario-container'>
                                    <div className='comentario-row'>
                                        <h3 className='comentario-txt'>@{comentario.username}</h3>
                                    </div>
                                    <p>{comentario.comment}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                </div>

            </div>
        </div>
    );
}

export default DetailCard;
