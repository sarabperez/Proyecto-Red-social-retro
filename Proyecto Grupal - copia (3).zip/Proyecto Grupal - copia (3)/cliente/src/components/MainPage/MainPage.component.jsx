import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'nes.css/css/nes.min.css';
import Navbar from '../Navbar/Navbar.component';
import StateCard from './Card.component';
import '../MainPage/MainPage.style.css';
import { useNavigate } from 'react-router-dom';

function MainPage() {
    const [elements, setElements] = useState([]);
    const navigate = useNavigate();
    useEffect(() => {
        const fetchElements = async () => {
            try {
                const response = await axios.get('http://localhost:5000/states/all');
                console.log(response.data);
                setElements(response.data);
            } catch (error) {
                console.error('Error al obtener elementos:', error);
            }
        };
        fetchElements();
    }, []);

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    return (
        <div className="nes-container is-dark" id='contenedor-princ'>
            <Navbar />
            <div className='nes-container is-dark with-title'>
                <div className="tweets">
                    {elements.map((element, index) => (
                        <StateCard
                            key={index}
                            id={element._id}
                            title={element.title}
                            imageUrl={"http://localhost:5000" + element.imageUrl}
                            user={element.user}
                            description={element.description}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}

export default MainPage;

