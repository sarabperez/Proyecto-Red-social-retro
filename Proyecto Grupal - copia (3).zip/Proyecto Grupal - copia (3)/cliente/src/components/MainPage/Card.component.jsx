import React from 'react';
import 'nes.css/css/nes.min.css';
import '../MainPage/MainPage.style.css';
import { useNavigate } from 'react-router-dom';

const StateCard = (props) => {
    const navigate = useNavigate();
    const { id, title, imageUrl, user, description } = props;
    const truncateText = (text, maxLength) => {
        if (text.length > maxLength) {
            return text.substring(0, maxLength) + '...';
        } else {
            return text;
        }
    };

    const redirect = (id) => {
        navigate(`/states/${id}`);
    };

    

    return (
        <div onClick={() => redirect(id)}>
            <h3 className='user-text'> @{user}</h3>
            <div className="nes-container is-dark with-title" id='card-state'>
                <div>
                    <h2 className="tweet-text">{title}</h2>
                    <p className='tweet-text'>{truncateText(description, 40)}</p>
                </div>{
                    console.log(imageUrl)
                }

                <img src={imageUrl} alt={user} className="img-user" />
            </div>
        </div>
    );
}

export default StateCard;


