import React, { useState } from 'react';
import axios from 'axios';
import '../Register/Register.style.css';
import { useNavigate } from 'react-router-dom';

const UserRegister = () => {

    const navigate = useNavigate();
    const irLogin = () => {
        navigate('/Login');
    }
    const [registerData, setRegisterData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        profile: '',
        description: ''
    });
    let passwordsMatch = registerData.password === registerData.confirmPassword ? '' : 'Las contraseñas deben coincidir';
    const txtContrasenia = () => {
        passwordsMatch = registerData.password === registerData.confirmPassword ? '' : 'Las contraseñas deben coincidir';
    };

    const handleRegisterChange = (e) => {
        txtContrasenia();
        const { name, value } = e.target;
        setRegisterData({ ...registerData, [name]: value });
    };

    const handleRegisterSubmit = async (e) => {
        e.preventDefault();
        if (registerData.password !== registerData.confirmPassword) {
            alert("Las contraseñas no coinciden");
            return;
        }
        try {
            const response = await axios.post("http://localhost:5000/Users/register", registerData);
            console.log(response);
            localStorage.setItem('username', registerData.username);
            localStorage.setItem('token', response.data.token);
            navigate('/login');
            alert("Usuario registrado correctamente");
        } catch (error) {
            console.error('Error:', error);
            alert("Error al registrar usuario");
        }
    };

    return (
        <div className="Login-Container">
            <form className="nes-container is-dark with-title" onSubmit={handleRegisterSubmit}>
                <h2 className='title'>Registrarse</h2>
                <div style={{ backgroundColor: '#212529', padding: '1rem' }} className='nes-field'>
                    <label htmlFor='name_field' style={{ color: '#fff' }}> Usuario</label>
                    <input
                        type="text"
                        id='name_field'
                        className='nes-input is-dark'
                        name="username"
                        placeholder="username"
                        value={registerData.username}
                        onChange={handleRegisterChange}
                    />
                </div>
                <div style={{ backgroundColor: '#212529', padding: '1rem', marginTop: 25 }} className='nes-field'>
                    <label htmlFor='email_field' style={{ color: '#fff' }}>Correo</label>
                    <input
                        type="text"
                        id='email_field'
                        className='nes-input is-dark'
                        name="email"
                        placeholder="email"
                        value={registerData.email}
                        onChange={handleRegisterChange}
                    />
                </div>
                <div style={{ backgroundColor: '#212529', padding: '1rem', marginTop: 25 }} className='nes-field'>
                    <label htmlFor='password_field' style={{ color: '#fff' }}>Contraseña</label>
                    <input
                        type="password"
                        id='password_field'
                        className='nes-input is-dark'
                        name="password"
                        placeholder="password"
                        value={registerData.password}
                        onChange={handleRegisterChange}
                    />
                </div>
                <div style={{ backgroundColor: '#212529', padding: '1rem', marginTop: 25 }} className='nes-field'>
                    <label htmlFor='confirm_field' style={{ color: '#fff' }}>Confirmar Contraseña</label>
                    <input
                        type="password"
                        id='confirm_field'
                        className='nes-input is-dark'
                        name="confirmPassword"
                        placeholder="password"
                        value={registerData.confirmPassword}
                        onChange={handleRegisterChange}
                    />
                </div>
                <span className="nes-text is-error">{passwordsMatch}</span>
                <div style={{ marginTop: 25 }}>
                    <button type="submit" className='nes-btn is-primary'>Registrarse</button>
                    <div style={{ marginTop: 50 }}>
                        <p className='irLogin'>¿Ya tienes una cuenta creada?</p>
                        <p onClick={irLogin} className='login'>Iniciar Sesion</p>
                    </div>

                </div>


            </form>
        </div>
    );
};

export default UserRegister;

