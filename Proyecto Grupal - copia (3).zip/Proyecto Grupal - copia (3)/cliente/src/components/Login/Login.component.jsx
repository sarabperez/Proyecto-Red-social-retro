import React, { useState } from 'react';
import axios from 'axios';
import 'nes.css/css/nes.min.css';
import '../Login/Login.style.css';
import { useNavigate } from 'react-router-dom';

const UserLogin = () => {

    const navigate = useNavigate();
    const irRegister = () => {
        navigate('/Register');
    }
    const [loginData, setLoginData] = useState({
        username: '',
        password: ''
    });

    const handleLoginChange = (e) => {
        const { name, value } = e.target;
        setLoginData({ ...loginData, [name]: value });
    };

    const handleLoginSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/Users/login", loginData);
            console.log(response);
            localStorage.setItem('token', response.data.token);
            navigate('/states');
            alert("Inicio de sesión exitoso");
        } catch (error) {
            console.error('Error:', error);
            alert("Error al iniciar sesión");
        }
    };

    return (
        <div className="Login-Container" style={{ display: 'flex', justifyContent: 'space-between' }}>
            <form className="nes-container is-dark with-title" onSubmit={handleLoginSubmit}>
                <h2 className='title'>Iniciar Sesión</h2>
                <div style={{ backgroundColor: '#212529', padding: '1rem' }} className='nes-field'>
                    <label htmlFor='name_field' style={{ color: '#fff' }}>Username</label>
                    <input
                        type="text"
                        id='name_field'
                        className='nes-input is-dark'
                        name="username"
                        placeholder="username"
                        value={loginData.email}
                        onChange={handleLoginChange}
                    />
                </div>
                <div style={{ backgroundColor: '#212529', padding: '1rem', marginTop: 25 }} className='nes-field'>
                    <label htmlFor='password_field' style={{ color: '#fff' }} >Contraseña</label>
                    <input
                        type="password"
                        id='password_field'
                        className='nes-input is-dark'
                        name="password"
                        placeholder="password"
                        value={loginData.password}
                        onChange={handleLoginChange}
                    />
                </div>
                <div style={{ marginTop: 25 }}>
                    <button className="nes-btn is-primary" type="submit">Iniciar Sesión</button>
                    <div style={{ marginTop: 50 }}>
                        <p className='moverseTxt' >¿Primera vez?</p>
                        <p onClick={irRegister} className='moverse'>Registrarse</p>
                    </div>

                </div>
            </form>
        </div>
    );
};

export default UserLogin;

