import React from 'react';
import 'nes.css/css/nes.min.css';
import '../Navbar/Navbar.style.css'

function Navbar() {
    const handleLogout = () =>{
        localStorage.removeItem("username");
    }
    return (
        <div className='nes-container is-rounded is-dark'>
            <div className='contenedor'>
                <div className='nav-item'>
                    <i className="nes-icon twitter is-medium"></i>
                    <a href="/" className="nav-link">"Twitter"</a>
                </div>
                <div className='right'>
                    <div className='nav-item'>
                        <i className="nes-icon trophy is-medium"></i>
                        <a href="/states" className="nav-link">Main Page</a>
                    </div>
                    <div className='nav-item'>
                        <i className="nes-icon coin is-medium"></i>
                        <a href="/profile" className="nav-link">Profile</a>
                    </div>
                    <div className='nav-item'>
                        <i className="nes-icon star is-medium"></i>
                        <a href="/login" className="nav-link" onClick={handleLogout}>Log out</a>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Navbar;