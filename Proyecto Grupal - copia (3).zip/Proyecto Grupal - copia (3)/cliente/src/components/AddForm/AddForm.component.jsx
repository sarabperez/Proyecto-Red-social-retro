import React from 'react';
import 'nes.css/css/nes.min.css';
import Navbar from '../Navbar/Navbar.component';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useState,  useEffect } from 'react';
import '../AddForm/AddForm.style.css';
import DragAndDropUploader from './DragAndDrop.component';

function AddForm() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        image: ''
    });
    const handleChange = (e) => {

        setFormData({ ...formData, [e.target.name]: e.target.value });
    }

    const handleFileChange = (e) => {
        console.log('File selected:', e.target.files[0]);
        setFormData({ ...formData, [e.target.name]: e.target.files[0] });
    }



    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const data = new FormData();
            const token = localStorage.getItem("token");
            data.append("image", formData["image"])
            data.append("title", formData["title"])
            data.append("description", formData["description"])
            data.append("user", formData["user"])
            await axios.post('http://localhost:5000/states/states/new', data, {
                headers: { 
                    "Content-Type": "multipart/form-data",
                    "Authorization": `Bearer ${token}` 
                }
            })
            navigate('/states');
        }
        catch (error) {
            console.error('Error al agregar el tweet', error.message);
        }
    };

    useEffect(() => {
        const isTokenValid = () => {
            const token = localStorage.getItem('token');
            if (!token) {
                return false;
            }

            const tokenData = JSON.parse(atob(token.split('.')[1]));
            const expirationTime = tokenData.exp * 1000;
            const currentTime = new Date().getTime();

            return expirationTime > currentTime;
        };

        if (!isTokenValid()) {
            alert('Inicia Sesion para navegar en la pagina')
            navigate('/');
        }
    }, [navigate]);

    return (
        <div className='nes-container is-dark' id='contenedor-princ'>
            <div>
                <Navbar />
            </div>

            <div className='nes-container is-rounded is-dark'>
                <form onSubmit={handleSubmit} className='contenedor-add'>
                    <div className='arriba'>
                        <div className='tweet-item'>
                            <label htmlFor="textarea_field" style={{ marginLeft: 75 }}>Imagen del estado</label>
                            <DragAndDropUploader image={formData.image} handleFileChange={handleFileChange} />
                        </div>
                        <div className="tweet-item" id='text-title'>
                            <label htmlFor="inline_field">Titulo</label>
                            <input type="text" name="title" id="inline_field" className="nes-input is-success" placeholder="Agregue un titulo para su estado" value={formData.title} onChange={handleChange} />
                        </div>
                    </div>
                    <div className="tweet-item">
                        <input
                            type="file"
                            id="imagearea_field"
                            name='image'
                            className="nes-input is-success"
                            placeholder='Ingrese la URL de la imagen de perfil'
                            onChange={handleFileChange}
                            required //este se puede borrar en cuanto funcione el drop
                            style={{ display: 'block' }} // Oculta el input de archivo si se utiliza el área de drop
                        />
                    </div>

                    <div className='tweet-item'>
                        <label htmlFor="textarea_field">Descripcion del estado</label>
                        <textarea id="textarea_field" name='description' className="nes-textarea" placeholder='Inserte una descripcion para el estado' value={formData.description} onChange={handleChange} />
                    </div>

                    <button type="submit" className="nes-btn is-success">Añadir estado</button>
                </form>

            </div >

        </div >
    );

}

export default AddForm;
