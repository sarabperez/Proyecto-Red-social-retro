
import '../AddForm/AddForm.style.css';
import React, { useRef } from 'react';



const DragAndDropUploader = ({ image, handleFileChange }) => {

    const inputRef = useRef(null);



    return (
        <div className="drag-drop-zone" >
            {image && <img src={URL.createObjectURL(image)} className='fondo' alt="Imagen de perfil" />}
            {!image && <p>aqui se verá la vista previa de la imagen</p>}
            <input
                type="file"
                ref={inputRef}
                onChange={handleFileChange}
                style={{ display: 'none' }}
            />
        </div>
    );
};

export default DragAndDropUploader;
