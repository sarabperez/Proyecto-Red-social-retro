const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true
    },
    description: {
        type: String,
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Por favor ingrese un email valido']
    },
    password: {
        type: String,
        required: true,
        minlength: [8, 'La contraseña debe contener al menos 8 caracteres']
    },
    profile: {
        type: String,
    }
});

module.exports = mongoose.model('User', userSchema);