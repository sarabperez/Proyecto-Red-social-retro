const State = require('../Modelos/State.model');
exports.createState = async (req, res) => {
    try {
        const imageFileName = req.file ? req.file.filename : null;
        const token = req.headers.authorization;
        const tokenData = JSON.parse(atob(token.split('.')[1]));
        const { description, title} = req.body;
        const newStateData = {
            user: tokenData.username,
            title: title,
            description: description,
            image: imageFileName,
            comments: []
        };
        const newState = await State.create(newStateData);
        res.status(201).json(newState);
    } catch (err) {
        console.error('Error al crear un nuevo state:', err);
        res.status(400).json({ error: err.message });
    }
};





//crear
/*
exports.createState = async (req, res) => {
    try {
        const newState = await State.create(req.body);
        res.status(201).json(newState);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};*/

// get 
exports.getAllStates = async (req, res) => {
    try {
        const states = await State.find();
        const statesWithImageUrl = states.map(state => ({
            ...state._doc,
            imageUrl: state.image ? `/upload/${state.image}` : null 
        }));
        res.status(200).json(statesWithImageUrl);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

//update
exports.updateState = async (req, res) => {
    try {
        const stateId = req.params.id;
        const updatedState = await State.findByIdAndUpdate(stateId, req.body, { new: true });
        if (!updatedState) {
            return res.status(404).json({ message: 'State not found' });
        }
        res.status(200).json(updatedState);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

//delete
exports.deleteState = async (req, res) => {
    try {
        const stateId = req.params.id;
        const deletedState = await State.findByIdAndDelete(stateId);
        if (!deletedState) {
            return res.status(404).json({ message: 'State not found' });
        }
        res.status(200).json({ message: 'State deleted successfully' });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

exports.newComment = async (req, res) => {
    const { id } = req.params;
    const { comment } = req.body;
    const token = req.headers.authorization;
    const tokenData = JSON.parse(atob(token.split('.')[1]));
    const username = tokenData.username;
    try {
        const state = await State.findById(id);
        if (!state) {
            return res.status(404).json({ error: 'State not found' });
        }

        state.comments.push({ comment, username});
        await state.save();

        res.status(201).json(state);
    } catch (error) {
        console.error('Error adding comment:', error);
        res.status(500).json({ error: 'Server error' });
    }
}


