const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const config = require('./Config/Mongo.config')
const userRoutes = require('./Rutas/User.routes');
const stateRoutes = require('./Rutas/State.routes');
const app = express();
config();

app.use(cors());
app.use(bodyParser.json());
app.use('/Users', userRoutes);
app.use('/states', stateRoutes);
app.use('/upload', express.static('upload'));
//app.use('/profile_images', express.static('profile_images'));





const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));