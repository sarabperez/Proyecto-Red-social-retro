
const fs = require('fs');
const multer = require('multer');

//verificar si la carpeta existe 
const uploadFolder = 'upload/';
//const profileImageFolder = 'profile_images/';

if (!fs.existsSync(uploadFolder)) {
    fs.mkdirSync(uploadFolder);
}

/*if (!fs.existsSync(profileImageFolder)) {
    fs.mkdirSync(profileImageFolder);
}
*/
// Configuración para estado
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'upload/'); // Directorio donde se guardarán los archivos
    },
    filename: function (req, file, cb) {
        const fileName = file.originalname.replace(/\s+/g, '_');//reemplaza espacios en blanco por guiones
        cb(null, Date.now() + '-' + fileName); // Nombre del archivo único
    }
});


//config para profile
/*const profileStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'profile_images/'); // Directorio donde se guardarán las imágenes de perfil de usuario
    },
    filename: function (req, file, cb) {
        const fileName = file.originalname.replace(/\s+/g, '_');
        cb(null, Date.now() + '-' + fileName); // Nombre del archivo único
    }
}); 

*/

const fileFilter = function (req, file, cb) {
    // Permitir archivos de imagen y archivos con el nombre 'profile'
    if (file.mimetype.startsWith('image/')) {
        cb(null, true); // Aceptar el archivo
    } else {
        cb(new Error('Tipo de archivo no admitido o campo de archivo no permitido'), false); // Rechazar el archivo
    }
};

// Configuración de Multer
const upload = multer({
    storage: storage,
    fileFilter: fileFilter
});
/*
const uploadProfile = multer({
   storage: profileStorage,
   fileFilter: fileFilter
});
*/
module.exports = upload;