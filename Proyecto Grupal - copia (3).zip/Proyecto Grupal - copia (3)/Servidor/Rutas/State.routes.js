const express = require('express');
const router = express.Router();
const stateController = require('../Controladores/State.controller');
const upload = require('../Config/multerConfig'); // Importar la configuración de Multer


router.post('/states/new', upload.single("image"), stateController.createState);
router.get('/all', stateController.getAllStates);
router.post('/:id/comments', stateController.newComment);
router.delete('/delete/:id', stateController.deleteState);

module.exports = router;
