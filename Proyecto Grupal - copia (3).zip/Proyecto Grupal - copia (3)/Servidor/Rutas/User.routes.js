const express = require('express');
const router = express.Router();
const userController = require('../Controladores/User.controller');
const upload = require('../Config/multerConfig');

router.post('/register', userController.register);
router.post('/login', userController.login);
router.get('/all', userController.users);
router.put('/editUser/:id', upload.single("profile"), userController.updateUser);

module.exports = router;


